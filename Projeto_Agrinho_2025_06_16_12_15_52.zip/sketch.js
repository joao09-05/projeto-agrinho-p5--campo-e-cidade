// Variáveis para alternar entre campo e cidade
let estado = "campo"; // Pode ser "campo" ou "cidade"
let botaoTrocar; // Botão para alternar entre campo e cidade

// Função para configuração inicial
function setup() {
  createCanvas(600, 400);
  
  // Botão para alternar entre os modos
  botaoTrocar = createButton('Trocar para Cidade');
  botaoTrocar.position(20, 20);
  botaoTrocar.mousePressed(trocarCena); // Troca a cena ao clicar no botão
}

// Função para desenhar na tela
function draw() {
  if (estado === "campo") {
    desenharCampo();
  } else {
    desenharCidade();
  }
}

// Função que alterna entre as cenas
function trocarCena() {
  if (estado === "campo") {
    estado = "cidade";
    botaoTrocar.html('Trocar para Campo');
  } else {
    estado = "campo";
    botaoTrocar.html('Trocar para Cidade');
  }
}

// Função para desenhar o campo
function desenharCampo() {
  background(180, 230, 255); // Cor do céu
  // Céu
  fill(0, 255, 0);
  rect(0, height / 2, width, height / 2); // Grama
  
  // Plantações
  fill(139, 69, 19);
  for (let x = 50; x < width; x += 100) {
    rect(x, height - 80, 20, 50); // Plantações
  }
  
  // Animais - Representação de vacas
  fill(255);
  ellipse(100, height - 120, 40, 40); // Vaca 1
  ellipse(300, height - 120, 40, 40); // Vaca 2
  ellipse(500, height - 120, 40, 40); // Vaca 3
  
  // Sol
  fill(255, 204, 0);
  ellipse(width - 80, 80, 80, 80);
}

// Função para desenhar a cidade
function desenharCidade() {
  background(200, 200, 255); // Cor do céu da cidade
  
  // Céu
  fill(150);
  rect(0, height / 2, width, height / 2); // Asfalto da cidade
  
  // Prédios
  fill(100, 100, 255);
  rect(50, height - 180, 80, 180); // Prédio 1
  rect(150, height - 150, 100, 150); // Prédio 2
  rect(300, height - 220, 120, 220); // Prédio 3
  rect(500, height - 100, 70, 100);  // Prédio 4
  
  // Carros
  fill(255, 0, 0);
  rect(70, height - 80, 40, 20);  // Carro 1
  
  fill(0, 255, 0);
  rect(250, height - 80, 40, 20);  // Carro 2
  
  fill(0, 0, 255);
  rect(450, height - 80, 40, 20);  // Carro 3
  
  // Semáforo
  fill(0);
  rect(350, height - 180, 10, 40);
  fill(255, 0, 0); // Semáforo vermelho
  ellipse(355, height - 150, 10, 10);
  
  // Nuvens
  fill(255);
  ellipse(150, 100, 60, 40); // Nuvem 1
  ellipse(450, 50, 80, 50); // Nuvem 2
}
